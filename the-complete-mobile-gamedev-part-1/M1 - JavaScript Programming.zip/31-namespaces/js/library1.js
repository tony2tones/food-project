var SomeUncommonWordName = SomeUncommonWordName || {};

SomeUncommonWordName.sayHello = function() {
	console.log('hello');
};