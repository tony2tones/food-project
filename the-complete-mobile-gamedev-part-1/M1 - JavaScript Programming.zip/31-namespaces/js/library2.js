var sayHello = function() {
	alert('hello');
};